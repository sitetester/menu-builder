<?php
/**
 * @group
 */
class Issue2435Test extends PHPUnit\Framework\TestCase
{
    public function testOne()
    {
        $this->assertTrue(true);
    }
}
