<?php
use PHPUnit\Framework\TestCase;

class NoArgTestCaseTest extends TestCase
{
    public function testNothing()
    {
    }
}
