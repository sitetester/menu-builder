<?php
use PHPUnit\Framework\TestCase;

class NotVoidTestCase extends TestCase
{
}
